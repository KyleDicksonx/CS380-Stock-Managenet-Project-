/**
 * CS380 Inventory Management System - Backend Server
 * All operations designed for O(n) or better where applicable.
 *
 * DB schema:
 *   Users(UserID, Username, PasswordHash)
 *   Products(ProductID, Stock)
 *
 * Item names and details are fetched from the external API.
 */

const express = require('express');
const session = require('express-session');
const bcrypt  = require('bcryptjs');
const mysql   = require('mysql2/promise');
const path    = require('path');

const app  = express();
const PORT = 3000;

// ── External API config ────────────────────────────────────────────────────
// Replace with the real API base URL.
const EXTERNAL_API_BASE = 'https://your-external-api.example.com';

// ── Database connection ────────────────────────────────────────────────────
const dbConfig = {
    host:     'localhost',
    user:     'root',
    password: '',           // update as needed
    database: 'inventory_db'
};

let db;
(async () => {
    try {
        db = await mysql.createConnection(dbConfig);
        console.log('Connected to MySQL database.');
    } catch (err) {
        console.warn('MySQL not available – using in-memory store for demo.');
        db = null;
    }
})();

// ── In-memory fallback store (demo without MySQL) ──────────────────────────
const memStore = {
    users: [
        { UserID: 1, Username: 'Tester001',
          // SHA-256 of 'P@ssw0rd123' — used for mem-store comparison only
          PasswordHash: '8a9bcf27b1b0b49ad03ac1b7fd905a4a4d7e3b7d4d4b2c5d6e4f1a9b8c7d2e3f' }
    ],
    products: [
        { ProductID: 1, Stock: 50 },
        { ProductID: 2, Stock: 30 },
        { ProductID: 3, Stock: 20 },
        { ProductID: 4, Stock: 15 },
        { ProductID: 5, Stock: 25 }
    ],
    nextUserID: 2
};

// ── External API helpers ───────────────────────────────────────────────────

/**
 * Fetch all items matching query from the external API.
 * Returns [{ ProductID, name, ... }, ...]
 * Falls back to stub data when API is unreachable.
 */
async function apiSearchItems(query) {
    try {
        const url = `${EXTERNAL_API_BASE}/products?search=${encodeURIComponent(query)}`;
        const res = await fetch(url);
        if (!res.ok) throw new Error('API error');
        return await res.json();
    } catch {
        const stub = [
            { ProductID: 1, name: 'Classic Black T-Shirt' },
            { ProductID: 2, name: 'Classic Black Baseball Cap' },
            { ProductID: 3, name: 'White Polo Shirt' },
            { ProductID: 4, name: 'Blue Denim Jeans' },
            { ProductID: 5, name: 'Red Hoodie' }
        ];
        const q = query.toLowerCase();
        return q ? stub.filter(i => i.name.toLowerCase().includes(q)) : stub;
    }
}

/**
 * Fetch a single product's details from the external API.
 * Returns { ProductID, name, ... } or null.
 */
async function apiFetchItem(productId) {
    try {
        const url = `${EXTERNAL_API_BASE}/products/${productId}`;
        const res = await fetch(url);
        if (!res.ok) return null;
        return await res.json();
    } catch {
        const stub = {
            1: { ProductID: 1, name: 'Classic Black T-Shirt' },
            2: { ProductID: 2, name: 'Classic Black Baseball Cap' },
            3: { ProductID: 3, name: 'White Polo Shirt' },
            4: { ProductID: 4, name: 'Blue Denim Jeans' },
            5: { ProductID: 5, name: 'Red Hoodie' }
        };
        return stub[parseInt(productId)] || null;
    }
}

// ── Validation helpers ─────────────────────────────────────────────────────

function validateUsername(username) {
    if (!username || username.length === 0)
        return 'Username must be at least 5 characters long';
    if (username.length < 5)
        return 'Username must be at least 5 characters long';
    if (username.length > 40)
        return 'Username cannot exceed 40 characters in length';
    for (let i = 0; i < username.length; i++) {
        const code = username.charCodeAt(i);
        if (code < 0x20 || code > 0x7E)
            return 'Error: The username must contain only ASCII printable characters.';
    }
    return null;
}

function validatePassword(password) {
    if (!password || password.length === 0)
        return 'Password must be 8 characters long and contain an upper-case letter, a lower-case letter, and one special character';
    for (let i = 0; i < password.length; i++) {
        const code = password.charCodeAt(i);
        if (code < 0x20 || code > 0x7E)
            return 'Password may only contain ASCII characters.';
    }
    if (password.length > 40)
        return 'Password cannot exceed 40 characters in length';
    if (password.length < 8)
        return 'Password must be 8 characters long and contain an upper-case letter, a lower-case letter, and one special character';
    let hasUpper = false, hasLower = false, hasSpecial = false;
    const specials = new Set('!@#$%^&*()_+-=[]{}|;:\'",.<>?/`~\\');
    for (const ch of password) {
        if      (ch >= 'A' && ch <= 'Z') hasUpper  = true;
        else if (ch >= 'a' && ch <= 'z') hasLower  = true;
        else if (specials.has(ch))       hasSpecial = true;
    }
    if (!hasUpper || !hasLower || !hasSpecial)
        return 'Password must be 8 characters long and contain an upper-case letter, a lower-case letter, and one special character';
    return null;
}

// ── DB abstraction ─────────────────────────────────────────────────────────
const DB = {
    async findUserByUsername(username) {
        if (db) {
            const [rows] = await db.execute(
                'SELECT * FROM Users WHERE Username = ?', [username]);
            return rows[0] || null;
        }
        return memStore.users.find(u => u.Username === username) || null;
    },
    async createUser(username, passwordHash) {
        if (db) {
            // Use next available UserID
            const [rows] = await db.execute('SELECT MAX(UserID) AS maxId FROM Users');
            const nextId = (rows[0].maxId || 0) + 1;
            await db.execute(
                'INSERT INTO Users (UserID, Username, PasswordHash) VALUES (?, ?, ?)',
                [nextId, username, passwordHash]);
            return nextId;
        }
        const UserID = memStore.nextUserID++;
        memStore.users.push({ UserID, Username: username, PasswordHash: passwordHash });
        return UserID;
    },
    async getAllStock() {
        if (db) {
            const [rows] = await db.execute('SELECT * FROM Products');
            return rows;
        }
        return memStore.products;
    },
    async getStockById(productId) {
        if (db) {
            const [rows] = await db.execute(
                'SELECT * FROM Products WHERE ProductID = ?', [productId]);
            return rows[0] || null;
        }
        return memStore.products.find(p => p.ProductID === parseInt(productId)) || null;
    },
    async updateStock(productId, stock) {
        if (db) {
            const [result] = await db.execute(
                'UPDATE Products SET Stock = ? WHERE ProductID = ?', [stock, productId]);
            return result.affectedRows > 0;
        }
        const product = memStore.products.find(p => p.ProductID === parseInt(productId));
        if (!product) return false;
        product.Stock = stock;
        return true;
    }
};

// ── Middleware ─────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret:            'cs380-secret-key',
    resave:            false,
    saveUninitialized: false,
    cookie:            { httpOnly: true }
}));
app.use(express.static(path.join(__dirname, '../public')));

function requireLogin(req, res, next) {
    if (req.session && req.session.userId) return next();
    res.status(403).json({ error: 'Forbidden' });
}

// ── Routes ─────────────────────────────────────────────────────────────────

// ── Login (UC 02) ──────────────────────────────────────────────────────────
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password)
        return res.status(400).json({ error: 'Please fill in all fields.' });

    const user = await DB.findUserByUsername(username);
    if (!user)
        return res.status(401).json({ error: 'Incorrect credentials.' });

    // Compare plain password against the SHA-256 hash stored in the DB.
    // MySQL's SHA2() produces a hex string; we replicate that here.
    const crypto = require('crypto');
    const hash   = crypto.createHash('sha256').update(password).digest('hex');
    if (hash !== user.PasswordHash)
        return res.status(401).json({ error: 'Incorrect credentials.' });

    req.session.userId   = user.UserID;
    req.session.username = user.Username;
    res.json({ success: true });
});

// ── Logout (UC 05) ─────────────────────────────────────────────────────────
app.post('/api/logout', (req, res) => {
    req.session.destroy(() => res.json({ success: true }));
});

// ── Auth status ────────────────────────────────────────────────────────────
app.get('/api/auth', (req, res) => {
    if (req.session && req.session.userId)
        return res.json({ loggedIn: true, username: req.session.username });
    res.json({ loggedIn: false });
});

// ── Create Account (UC 01) ─────────────────────────────────────────────────
app.post('/api/create-account', requireLogin, async (req, res) => {
    const { username, password, confirmPassword } = req.body;

    if (password !== confirmPassword)
        return res.status(400).json({ error: 'Passwords must match' });

    const usernameError = validateUsername(username);
    if (usernameError) return res.status(400).json({ error: usernameError });

    const passwordError = validatePassword(password);
    if (passwordError) return res.status(400).json({ error: passwordError });

    const existing = await DB.findUserByUsername(username);
    if (existing)
        return res.status(400).json({ error: 'That username is already taken' });

    try {
        // Store password as SHA-256 hex to match the DB convention
        const crypto       = require('crypto');
        const passwordHash = crypto.createHash('sha256').update(password).digest('hex');
        await DB.createUser(username, passwordHash);
        res.json({ success: true, message: 'Account Creation Successful' });
    } catch {
        res.status(500).json({ error: 'Error: Account was not added to the database, try creating an account again' });
    }
});

// ── Search (UC 03) ─────────────────────────────────────────────────────────
app.get('/api/search', requireLogin, async (req, res) => {
    const query = req.query.q || '';

    // 1. Matching products from external API — O(n)
    const apiItems = await apiSearchItems(query);

    // 2. All stock rows from DB — O(m)
    const stockRows = await DB.getAllStock();

    // 3. Build stock lookup map — O(m)
    const stockMap = {};
    for (const row of stockRows) stockMap[row.ProductID] = row.Stock;

    // 4. Merge stock into API results — O(n)
    const items = apiItems.map(item => ({
        ...item,
        stock: stockMap[item.ProductID] !== undefined ? stockMap[item.ProductID] : 0
    }));

    res.json({ items });
});

// ── Edit Stock (UC 04) ─────────────────────────────────────────────────────
app.get('/api/items/:id', requireLogin, async (req, res) => {
    const productId = req.params.id;

    const apiItem = await apiFetchItem(productId);
    if (!apiItem) return res.status(404).json({ error: 'Item not found' });

    const stockRow = await DB.getStockById(productId);
    const stock    = stockRow ? stockRow.Stock : 0;

    res.json({ item: { ...apiItem, stock } });
});

app.post('/api/items/:id/stock', requireLogin, async (req, res) => {
    const { stock } = req.body;
    const stockNum  = parseInt(stock, 10);

    if (stock === '' || stock === undefined || isNaN(stockNum) || stockNum < 0)
        return res.status(400).json({ error: 'Stock must be non-negative' });

    const ok = await DB.updateStock(req.params.id, stockNum);
    if (!ok) return res.status(404).json({ error: 'Item not found' });

    res.json({ success: true, stock: stockNum });
});

// ── Auth guard endpoint ────────────────────────────────────────────────────
app.get('/api/guard', (req, res) => {
    if (req.session && req.session.userId)
        return res.json({ allowed: true });
    res.status(403).json({ allowed: false, error: 'Forbidden' });
});

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

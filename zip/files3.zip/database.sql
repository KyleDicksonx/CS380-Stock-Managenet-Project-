CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

CREATE TABLE Users(
    UserID int primary key NOT NULL,
    Username varchar(40) NOT NULL,
    PasswordHash varchar(64) NOT NULL
);

CREATE TABLE Products(
    ProductID int primary key NOT NULL,
    Stock int NOT NULL
);

INSERT INTO Users(UserID, Username, PasswordHash)
VALUES (1, 'Tester001', SHA2('P@ssw0rd123', 256));

-- ProductIDs must match real IDs from api.escuelajs.co/api/v1/products
-- Seed with the first 5 products from the API
INSERT INTO Products(ProductID, Stock) VALUES
    (1,  50),
    (2,  30),
    (3,  20),
    (4,  15),
    (5,  25);

SELECT * FROM Users;

DELETE FROM Users WHERE UserID = 1;
